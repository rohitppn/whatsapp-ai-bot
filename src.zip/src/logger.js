const fs = require("fs-extra");
const logFile = "./data/messages.json";

async function logMessage(senderId, senderName, message) {
  const timestamp = new Date().toISOString();
  const logEntry = { timestamp, senderId, senderName, message };

  try {
    const existing = await fs.readJson(logFile).catch(() => []);
    existing.push(logEntry);
    await fs.writeJson(logFile, existing, { spaces: 2 });
  } catch (err) {
    console.error("Failed to log message:", err);
  }
}

module.exports = { logMessage };
