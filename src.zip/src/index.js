require("dotenv").config();
const { Boom } = require("@hapi/boom");
const makeWASocket = require("@whiskeysockets/baileys").default;
const {
  useMultiFileAuthState,
  DisconnectReason,
} = require("@whiskeysockets/baileys");
const fs = require("fs-extra");
const { getReplyFromOpenAI } = require("./openai");
const { logMessage } = require("./logger");

const startBot = async () => {
  const { state, saveCreds } = await useMultiFileAuthState(
    process.env.SESSION_AUTH_PATH
  );

  const sock = makeWASocket({
    auth: state,
  });

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      console.log("\n📲 Scan this QR to log in:\n");
      console.log(qr);
    }

    if (connection === "close") {
      const shouldReconnect =
        lastDisconnect?.error?.output?.statusCode !==
        DisconnectReason.loggedOut;
      console.log("Connection closed. Reconnecting...", shouldReconnect);
      if (shouldReconnect) startBot();
    } else if (connection === "open") {
      console.log("✅ WhatsApp bot connected.");
    }
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    const msg = messages[0];
    if (!msg?.message || msg.key.fromMe) return;

    const sender = msg.pushName || msg.key.participant?.split("@")[0];
    const messageText =
      msg.message?.conversation || msg.message?.extendedTextMessage?.text;

    const isGroup = msg.key.remoteJid.endsWith("@g.us");
    const senderId = msg.key.participant || msg.key.remoteJid;

    // Read toggle flags from .env
    const replyInGroups = process.env.REPLY_IN_GROUPS === "true";
    const replyInPersonal = process.env.REPLY_IN_PERSONAL === "true";

    if (!messageText) return;

    // Skip based on flag
    if (isGroup && !replyInGroups) return;
    if (!isGroup && !replyInPersonal) return;

    logMessage(senderId, sender, messageText);

    const reply = await getReplyFromOpenAI(senderId, messageText);

    if (reply) {
      const messageOptions = isGroup
        ? {
            text: `@${sender.split(" ")[0]}, ${reply}`,
            mentions: [senderId],
          }
        : {
            text: reply,
          };

      await sock.sendMessage(msg.key.remoteJid, messageOptions);
    }
  });
};

startBot();
