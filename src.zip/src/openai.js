const fs = require("fs-extra");
const { OpenAI } = require("openai");

// Initialize OpenAI with your API key
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Memory map to store short-term conversation history
const userMemory = new Map();
const MAX_HISTORY = 5; // Keep last 5 messages for each user

async function getReplyFromOpenAI(userId, userMessage) {
  // Load Arunav's personality and training instructions
  const systemPrompt = await fs.readFile(
    "./training/knowledge_base.txt",
    "utf-8"
  );

  // Fetch user history or start fresh
  let memory = userMemory.get(userId) || [];

  // Add current user message to history
  memory.push({ role: "user", content: userMessage });

  // Limit to last 5 messages
  if (memory.length > MAX_HISTORY) {
    memory = memory.slice(-MAX_HISTORY);
  }

  // Prepare messages array with system prompt + conversation history
  const messages = [{ role: "system", content: systemPrompt }, ...memory];

  // Get completion from OpenAI
  const chatCompletion = await openai.chat.completions.create({
    model: "gpt-3.5-turbo",
    messages,
    temperature: 0.8,
  });

  const reply = chatCompletion.choices[0]?.message?.content.trim();

  // Add assistant reply to memory
  memory.push({ role: "assistant", content: reply });

  // Save updated history
  userMemory.set(userId, memory);

  return reply;
}

module.exports = { getReplyFromOpenAI };
