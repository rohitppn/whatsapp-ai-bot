const { getReplyFromOpenAI } = require("./openai");

async function handleGroupMessage(senderName, message) {
  try {
    if (message.length < 2) return null;
    const reply = await getReplyFromOpenAI(`${senderName} asked: ${message}`);
    return reply;
  } catch (err) {
    console.error("Error handling group message:", err);
    return "Sorry, something went wrong.";
  }
}

module.exports = { handleGroupMessage };
